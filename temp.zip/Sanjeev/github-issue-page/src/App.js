import './App.css';
import { FaRegDotCircle } from "react-icons/fa";
import { AiOutlineCheck } from 'react-icons/ai';
import IssueRow from './issue-row';
import { useEffect, useState } from 'react';

function App() {
  const [githubData, setGithubData] = useState([]);
  const [closed, setClosed] = useState(0);
  const [opened, setOpened] = useState(0);

  useEffect(() => {
    fetch("https://api.github.com/repos/facebook/react/issues")
      .then(data => data.json())
      .then((data) => {
        for (const issue of data) {
          if (issue.state === "open") setOpened(prev => prev + 1);
          else setClosed(prev => prev + 1);
        }
        setGithubData(data);
      });
  }, []);

  return (
    <div className="github-issue-page">
      <div className="github-issue-table">
        <div className="github-issue-table-heading">
          <div className="github-issue-table-heading-info">
            <FaRegDotCircle />
            <span className="github-issue-table-heading-main">
              {opened} Open
            </span>
          </div>
          <div className="github-issue-table-heading-info">
            <AiOutlineCheck />
            <span>
              {closed} Closed
            </span>
          </div>
        </div>
        {
          githubData.map((issue, index) => {
            return <IssueRow key={index} title={issue.title} comments={issue.comments} number={issue.number} assignee={issue.assignee} />
          })
        }
      </div>
    </div>
  );
}

export default App;
