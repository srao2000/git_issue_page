import './App.css';
import { FaRegDotCircle, FaRegCommentAlt } from "react-icons/fa";
import { BsPersonCircle } from 'react-icons/bs';

function IssueRow(props) {
  return (
    <div className='github-issue-table-row'>
      <FaRegDotCircle />
      <div className='github-issue-table-row-content'>
        <div className='github-issue-table-row-text'>
          <span className='github-issue-table-row-title'>
            {props.title}
          </span>
          <span className='github-issue-table-row-commit'>
            #{props.number} opened 19 hours ago by acdite
          </span>
        </div>
        <div className='github-issue-table-row-assign'>
          {props.assignee && <BsPersonCircle />}
        </div>
        <div className='github-issue-table-row-comment'>
          {
            props.comments > 0 && (
              <>
                <FaRegCommentAlt /> {props.comments}
              </>
            )
          }
        </div>
      </div>
    </div>
  );
}

export default IssueRow;